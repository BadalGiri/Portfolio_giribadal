Portfolio files for Giri Badal
----------------------------------
Files included:
- index.html
- css/styles.css
- images/profile-placeholder.svg

Instructions:
- Open index.html in a browser to preview.
- Replace images/profile-placeholder.svg with a real profile photo if available.
- The contact form is a demo (no backend). Hook it up with a server or Formspree for submissions.

To host:
- Upload the folder contents to GitHub and enable GitHub Pages from the repository settings,
  or use Netlify/Vercel for quick static hosting.
